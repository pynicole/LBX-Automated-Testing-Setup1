package  CMMS.SetupTest1.TestCases;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import java.io.File;
import java.time.Duration;
//import org.openqa.selenium.By;
//import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
//import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import CMMS.SetupTest1.PageObjects.PO_Common;
import CMMS.SetupTest1.TestCases.Utils.BrowserManager;

public class Automated_Test_1
{
	@Test
	@Parameters ({"browser", "url", "username", "password"})
	public void Automated_Test_Script_1(String browser, String url, String username, String password) throws InterruptedException {
		
		// Creates instance of driver based on specified browser and url
		WebDriver driver = BrowserManager.getDriver(browser,url);
		// Initializing Page Object for PO_Common class using provided driver instance
		PO_Common obj = PageFactory.initElements(driver, PO_Common.class);

		try {
			// EXAMPLES ///////////////////////////////////////////
		
			// Log into CMMS Dev website
			obj.Login_To_CMMS_Dev(driver, username, password);
		
			// Pause for 10 seconds
			Thread.sleep(10000);
		
			// Take screenshot
			obj.takeScreenshotWithTaskbar();	
			
		    ///////////////////////////////////////////////////////
			
			
			
			
			///////////// Start your test case below //////////////
			
			
			
		} catch (PO_Common.stepFailure e) {
			driver.quit();
			Assert.fail("Test failed due to step error.");
		}
		
		
		//This timeout is used to specify the time the driver should wait while 
		//searching for an element if it is not immediately present.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.close();
	

	}

}

