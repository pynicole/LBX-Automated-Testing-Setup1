package CMMS.SetupTest1.PageObjects;

import java.time.Duration;
import java.awt.AWTException;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;

import javax.imageio.ImageIO;

import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import junit.framework.Assert;

//Define the class PO_Common. It represents a common base class for Page Objects.
public class PO_Common 
{
		// Declare a member variable "driver" of type WebDriver. It will hold the web driver instance used for automation.
		WebDriver driver;
		
		// Define a constructor for the PO_Common class. It takes a WebDriver object as a parameter.
		public PO_Common(WebDriver driver) {
			// Assign the provided WebDriver instance to the member variable "driver".
			this.driver = driver;
		}	
		
		// Declare a private static member variable "timestamp" of type String.
		private static String timestamp;
		
		
	    public class stepFailure extends RuntimeException {
	        public stepFailure(String message) {
	            super(message);
	        }
	    }
		
		
		

		
		
//----- PAGE OBJECTS -------------------------------------------------------------------------------------//
//-- This is where you define the specific button, field, or section on the webpage that you want to -----//
//-- interact with. Ideally you want to section them to what type of object and in alphabetical order ----//
//-- so you can find them easily. Below is an example on how to define an object. ------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the object is and on what specific page                                  //
// @FindBy(put what html tag you want to reference: should be id/name/or xpath (xpath most preferred)     //
// private WebElement insertNameOfObjectHere;                                                             //
//--------------------------------------------------------------------------------------------------------//
	   	
		
//****** CMMS Dev website section ******//		
		
	//--- BUTTONS/TABS ---//
		
		//CMMS Login Button
		@FindBy(id ="button-1036-btnInnerEl")
		private WebElement btn_LOGIN;	
		
		//CMMS the equipment tab
		@FindBy(xpath = "/html[@id='ext-element-6']/body[@id='ext-element-1']/div[@id='index-1026']/div[@id='index-1026-bodyWrap']/div[@id='index-1026-body']/div[@id='index-1026-innerCt']/div[@id='index-1026-targetEl']/div[@id='container-1027']/div[@id='container-1027-innerCt']/div[@id='container-1027-targetEl']/div[@id='mainmenubar-1032']/div[@id='mainmenubar-1032-innerCt']/div[@id='mainmenubar-1032-targetEl']/a[@id='button-1048']/span[@id='button-1048-btnWrap']/span[@id='button-1048-btnEl']/span[@id='button-1048-btnInnerEl']")
	    private WebElement EquipmentButton;
		
	    //CMMS Dev: Equipment dropdown menu
	    @FindBy(id="button-1048-btnInnerEl")
	  	private WebElement EquipmentMenuDropdown;
		
	  	//CMMS Dev: Search button on search bar
	  	@FindBy(id="uxpicktriggerfield-1297-trigger-trigger")
	  	private WebElement EquipmentSearchButton;

	  	//CMMS Dev: New Record button on Equipment page from Equipment dropdown
	  	@FindBy(xpath="//*[@id=\"button-1246-btnIconEl\"]")
	  	private WebElement NewRecordButton;
	  	
	  	//CMMS Dev: A new pop-up message when loggin in - OK button for this
	  	@FindBy(xpath="//*[@id=\"button-1013-btnInnerEl\"]")
	  	private WebElement OKButton;
	  	
	  	//CMMS Dev: Save Record button
	  	@FindBy(xpath="//*[@id=\"button-1245-btnIconEl\"]")
	  	private WebElement SaveRecordButton;
	  	
	  	
	//--- USER FIELDS ---//
	  	
	  	//CMMS Dev: Field for Equipment Name
	  	@FindBy(xpath="//*[@id=\"textfield-1395-inputEl\"]")
	  	private WebElement EquipmentNameField;	 
	  	
	  	//CMMS Dev: Field for Equipment Type
	  	@FindBy(xpath="//*[@id=\"lovfield-1406-inputEl\"]")
	  	private WebElement EquipmentTypeField;
		
		//CMMS Testing Biogen, "password field"
		@FindBy(id="textfield-1035-inputEl")
		private WebElement PasswordField;
		
		//CMMS Testing Biogen, "User Id field"
		@FindBy(id ="textfield-1034-inputEl")
		private WebElement UserField;
		
		
	//--- SEARCH BARS / SEARCH BAR SELECTION ---//
		
	  	//CMMS Dev: Equipment search bar
	  	@FindBy(name="summarysearch")
	  	private WebElement EquipmentSearchBar;
	  	
	  	//CMMS Dev: First selection on search bar
	  	@FindBy(xpath = "//*[@id=\"ext-element-27\"]")
	  	private WebElement FirstSearchOption;
	  	
	  	//CMMS Dev: Second option in search bar
	  	@FindBy(xpath="//*[@id=\"uxgridsummaryview-1816\"]/div[2]")
	  	private WebElement SecondSearchOption;
	  	
		
		
		
		
		
//----- METHODS ------------------------------------------------------------------------------------------//
//-- This is where you define the specific methods (actions) that you want to do to the webpage. ---------//
//-- Ideally you want to section them to what type of method it is and in alphabetical order -------------//
//-- so you can find them easily. Below is an example on how to define a method. -------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the action is to what page objects                                       //
// public void nameOfActionHere() {                                                                       //
//     try {                                                                                              //
//	        nameOfPageObjectYouWant.click() or .sendKeys(wordYouWantToEnter)                              //
//	  	    refreshTimestamp();   (used to get the current time)                                          //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//  	    Reporter.log("This should be the "Actual" result of the action being done", true);            //
//  	    Reporter.log(timestamp, true);    (timestamps the action to the current time)                 //
//     } catch (Exception e) {                                                                            //
//          e.printStackTrace();    (will output the error if an error occurs)                            //
//          refreshTimestamp();                                                                           //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//		    Reporter.log("Step failed.", true);                                                           //
//		    Reporter.log(timestamp, true);                                                                //
//          throw new stepFailure("Step failed."); (stops the test and marks as failure)                  //
//     }                                                                                                  //
// }                                                                                                      //
//--------------------------------------------------------------------------------------------------------// 
	  	
	  	
//****** Commonly used methods ******//		
	  	
	  	
	  	private static void refreshTimestamp() {
	        // Update the timestamp with the current date and time
	        timestamp = new SimpleDateFormat("dd-MMM-yy HH:mm:ss").format(new Date());
	    }
	  	
	  	public void takeScreenshotWithTaskbar() {
	  	    try {
	  	        // Create a Robot object to capture the screen pixels
	  	        Robot robot = new Robot();

	  	        // Determine the size of the screen
	  	        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());

	  	        // Capture the screen shot of the entire screen
	  	        BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
	  	        
	  	        // Generate a unique file name based on the current timestamp
	  	        String fileName = "screenshot_" + getTimestamp() + ".jpg";

	  	        File destination = new File("D:\\Users\\nrodgers\\Automated Testing Screenshots\\" + fileName);

	  	        // Save the screenshot to the specified location
	  	        ImageIO.write(screenFullImage, "jpg", destination);
	  	        
	  	        System.out.println("Screenshot captured: " + destination.getAbsolutePath());
	  	        refreshTimestamp();

	  	        // Convert the screenshot to Base64 encoded string
	  	        String base64Screenshot = convertToBase64(destination);

	  	        // Embed the screenshot image into the TestNG report using <img> tag with Base64 data
	  	        String imgTag = "<img src=\"data:image/jpeg;base64," + base64Screenshot + "\" alt=\"Screenshot\" height=\"250\" />";
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Screenshot captured: </br>" + imgTag, true);
	  	        Reporter.log(timestamp, true);

	  	        // adding the img to an array to be called on later
	  	        imgTags.add(imgTag);
	  	        
	  	    } catch (Exception ex) {
	  	        ex.printStackTrace();
	  	        
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	    }
	  	}


	    private String convertToBase64(File file) throws IOException {
	        byte[] fileContent = Files.readAllBytes(file.toPath());
	        return Base64.getEncoder().encodeToString(fileContent);
	    }
	

		private String getTimestamp() {
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		    return sdf.format(new Date());
		}
		
	  	public ArrayList<String> imgTags = new ArrayList<>();

	    // Getter method to access the imgTags ArrayList
	    public ArrayList<String> getImgTags() {
	        return imgTags;
	    }
	  	
	  	
	  	
//****** CMMS Dev website section ******//	
		
		
	//---------- LOGIN ----------//
		
		//Biogen enter username and password and login to dev CMMS
		public void Login_To_CMMS_Dev(WebDriver driver, String username, String password) throws InterruptedException 
		{
			
			EnterUsername(username); 	

			EnterPassword(password); 	
			
			btn_LOGIN.click(); 	
			

			//watch this video, figure out how to reference driver in this method
			//https://www.youtube.com/watch?v=evRGeTo8TME
			
			//Close the browser
			//driver.quit();
	
		}
	  	
	//---------- CLICK ----------//

		//CMMS - login button clicking
		public void ClickLoginButton() {
			try {
				btn_LOGIN.click();
				refreshTimestamp();
				Reporter.log("Click CMMS Dev login button. " ,true);
				Reporter.log("Login button clicked. " ,true);
				Reporter.log(timestamp ,true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click CMMS Dev login button. " ,true);
				Reporter.log("Step failed. " ,true);
				Reporter.log(timestamp ,true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		

		
	//---------- SENDKEYS ----------//
	  	
		//CMMS - send the password to the field
		public void EnterPassword(String password) {
			try {
				PasswordField.sendKeys(password);
				refreshTimestamp();
				Reporter.log("Entered Password. ", true);
	  	        Reporter.log("Password entered successfully. ", true);
	  	        Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Entered Password. ", true);
	  	        Reporter.log("Step failed. ", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS - send the user name to the field
	  	public void EnterUsername(String username) {
	  	    try {
	  	        UserField.sendKeys(username);
	  	        refreshTimestamp();
	  	        Reporter.log("Entered Username. ", true);
	  	        Reporter.log("Username entered successfully. ", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Entered Username. ", true);
	  	        Reporter.log("Step failed. ", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	

}
